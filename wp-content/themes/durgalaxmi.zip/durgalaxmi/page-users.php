<?php get_header() ?>
<div class="outer">
    <div class="container-fluid page p-0 ">
        <div class="page-content bg-light">
            <?php the_content() ?>
        </div>

    </div>
    <?php get_footer() ?>